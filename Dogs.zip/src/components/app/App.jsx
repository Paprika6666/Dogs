import React, { useEffect,useState } from 'react';
import { Footer } from '../Footer/Footer';
import { Header } from '../header/Header';
import './App.css';
import { api } from '../../Utils/api.js';
import { useDebounce } from '../../Utils/utils';
import { Route, Routes } from 'react-router-dom';
import { ProductPage } from '../../pages/ProductPage/ProductPage';
import { CatalogPage } from '../../pages/CatalogPage/CatalogPage.jsx';

// import Datepicker from '../DatePicker/DatePicker';





function App() {
  const [cards, setCards] = useState([]);
  const [searchQuery, setSearchQuery]=useState('');
  const [parentCounter, setParentCounter]=useState (0);
  const [currentUser, setCurrentUser]=useState ({});
  
const handleSearch = (search) => {
 api.searchProducts (search).then ((data) => setCards ([...data]));
};

const debounceValueInApp = useDebounce (searchQuery, 500);

function handleProductLike (product) {
  const isLiked = product.likes.some((el)=> el === currentUser._id);
    console.log ('product', product); 

  isLiked ?  api.deleteLike (product._id).then ((newCard)=>{
    const newCards = cards.map ((e) => e._id === newCard._id ? newCard : e);
setCards([...newCards]);
console.log('newCard', newCard);

  })
   : api.addLike (product._id).then ((newCard)=>{
    const newCards = cards.map ((e) => e._id === newCard._id ? newCard : e);
    setCards([...newCards]);
});
}
// console.log ('currentUser', currentUser._id);

useEffect(()=>{
 
  handleSearch (debounceValueInApp);
  // console.log ( {debounceValueInApp});
    }, [debounceValueInApp]);

    // console.log (cards, searchQuery);


      useEffect (()=> {

        Promise.all ([api.getUserInfo(), api.getProductList()]).then(
          ([userData, productData]) =>{
          setCurrentUser (userData);
          setCards (productData.products);
        });
        // api.getProductList().then ((data)=>setCards(data.products));
        // api.getUserInfo().then ((data) => setCurrentUser(data));
        // getProductList().then ((data) => setCards(data.products)); - без классов
      },[]);
  
  return (
    <>
     {/* heder */}
     <Header
      user = {currentUser}
      parentCounter ={parentCounter}
      searchQuery = {searchQuery}
      setSearchQuery={setSearchQuery}
      />
     
     <main className="content container">
      

    <Routes>

    <Route 
    path='/' 
    element={
      <CatalogPage 
      searchQuery = {searchQuery} 
      cards = {cards} 
      currentUser = {currentUser} 
      handleProductLike = {handleProductLike} 
      setParentCounter = {setParentCounter}
      />
      }
      ></Route>
        <Route path="/product/:productId" 
      element={<ProductPage currentUser ={currentUser}/>}
      ></Route>
    </Routes>
     </main>
     {/* footer */}
     <Footer />
    </>
  );
}

export default App;
